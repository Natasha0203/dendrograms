# Dendrograms for Correlation Matrices
A suggestion code for building dendrograms in R. Includes diferents kinds: circle, phylo and trees. 
It also demonstrates how to change colors and sizes.
